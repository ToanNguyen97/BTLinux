class Khoa :
    def __init__ (self,maso,name):
         
	self.maso = maso 
        self.name = name
 
    def showInfo(self):
         
	print "Ma :", self.maso
        print "Ten khoa:", self.name
