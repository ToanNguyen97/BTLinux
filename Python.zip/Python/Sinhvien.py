class Sinhvien :
    def __init__ (self,maso="",name="",makhoa=""):
         
	self.maso = maso 
        self.name = name
	self.makhoa = makhoa
 
    def showInfo(self):
         
	print "MaSV :", self.maso
        print "Ten sinh vien:", self.name
	print "ma khoa:", self.makhoa

    def getmakhoa(self):
        return self.makhoa
