from SINHVIEN import SINHVIEN
print '---danh sach Sinh Vien-----'
sv1 = SINHVIEN()
sv1.set_ten()
sv1.set_namSinh()
sv1.set_khoa()
sv1.toString()

