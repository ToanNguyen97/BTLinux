n = input("n= ")
s=0
for i in range(1,n):
   print '%d '%(i)
print '-----------------'
for i in range(1,n):
  if (i%2 ==0):
     s = s+i
print 'tong la: %d'%(s) 
  


