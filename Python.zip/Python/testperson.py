from Khoa import Khoa
from SINHVIEN import SINHVIEN
print '---danh sach khoa-----'
khoa1 = Khoa("01","CNTT")
khoa1.showInfo()
khoa2 = Khoa( "02","KT")
khoa2.showInfo()
khoa3 = Khoa("03","Co khi")
khoa3.showInfo()
khoa4 = Khoa("04","Nuoi")
khoa4.showInfo()
print '---danh sach Sinh Vien-----'
sv1 = SINHVIEN()
sv1.set_ten()
sv1.set_namSinh()
sv1.set_khoa()
sv1.toString()


