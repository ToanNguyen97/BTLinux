from bikeu import Toan
sv1 = Toan()
sv1.set_ten()
sv1.set_sdt()
print 'thong tin'
sv1.In()
