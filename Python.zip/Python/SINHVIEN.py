#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class SINHVIEN:
	def __init__(self,ten="",namSinh="",khoa=""):
		self.ten=ten
		self.namSinh=namSinh
		self.khoa=khoa
	def get_ten(self):
		return self.ten
	def get_namSinh(self):
		return self.namSinh
	def get_khoa(self):
		return self.khoa
	def set_ten(self):
		ten=input('Nhập tên của sinh viên: ')
		self.ten=ten
	def set_namSinh(self):
		namSinh=input('Nhập năm sinh của sinh viên: ')
		self.namSinh=namSinh
	def set_khoa(self):
		khoa=input('Nhập khóa học của sinh viên: ')
		self.khoa=khoa 
	def toString(self):
		print 'tên:',self.get_ten()
		print 'năm sinh:',self.get_namSinh()
		print 'khóa:',self.get_khoa()
