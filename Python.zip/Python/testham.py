from sohoc import Tinh(a,b)
a = input("a= ")
b = input("b=")
print '----ket qua--------'
Tinh(a,b)
