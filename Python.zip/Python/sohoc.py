def Tinh(a,b):
  print '%d+%d=%d'%(a,b,a+b)
  print '%d-%d=%d'%(a,b,a-b)
  print '%d*%d=%d'%(a,b,a*b)
  print '%d/%d=%f'%(a,b,a/b)
  print '%mod%d=%f'%(a,b,a%b)
  print '%d**%d=%d'%(a,b,a**b)


print '---ket qua---'
Tinh(4,5)

