a = input("a= ")
b = input("b= ")
a,b=b,a
print 'a=%d ;b=%d'%(a,b)
