#!/bin/bash
clear
echo "Hello World"
echo "Today is: "; date
echo "tên đăng nhập : $LOGNAME";
echo "Thư mục hiện hành : " ; pwd
echo "mời nhập vào từ bạn muốn :";
read a

