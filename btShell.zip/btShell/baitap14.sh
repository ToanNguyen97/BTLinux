echo "nhap vao so thu nhat "
read a
echo "nhap vao so thu nhat "
read b
echo "nhap vao so thu nhat "
read c
if [ $a -eq 0 ]
{
   if [ $c -eq 0 ]
     then
      echo "phương trình vô số nghiệm "
   elif [ $b -eq 0 ]
     then 
      echo "Phương trình vô nghiệm "
   else 
      echo "kết quả : "`expr -$c / $b`
   fi
}
elif []
 
     

